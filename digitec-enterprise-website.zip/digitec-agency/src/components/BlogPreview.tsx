import { ArrowUpRight } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";

const placeholders = [
  { title: "5 SEO Fundamentals Every UK Business Should Get Right in 2026", tag: "SEO" },
  { title: "How to Brief a Web Developer So You Get the Site You Actually Want", tag: "Web Design" },
  { title: "Paid vs Organic: Building a Social Strategy That Balances Both", tag: "Social Media" },
];

export default function BlogPreview() {
  return (
    <section className="section">
      <div className="container-px">
        <SectionHeading eyebrow="Latest Blog" title="Insights on growing your business online" />
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {placeholders.map((p) => (
            <article key={p.title} className="glass-card group flex h-full flex-col p-7">
              <span className="eyebrow">{p.tag}</span>
              <h3 className="mt-3 flex-1 font-display text-lg font-semibold leading-snug text-frost-100">
                {p.title}
              </h3>
              <span className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-brand-light">
                Coming soon <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </span>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
