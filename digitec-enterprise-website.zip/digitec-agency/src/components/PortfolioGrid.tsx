"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence, LayoutGroup } from "framer-motion";
import { ArrowUpRight, X } from "lucide-react";
import { portfolio, type PortfolioCategory, type PortfolioItem } from "@/lib/data";
import { cn } from "@/lib/utils";

const categories: (PortfolioCategory | "All")[] = [
  "All",
  "Web Design",
  "E-commerce",
  "Branding",
  "Social Media",
];

export default function PortfolioGrid({
  limit,
  showFilters = true,
}: {
  limit?: number;
  showFilters?: boolean;
}) {
  const [active, setActive] = useState<(PortfolioCategory | "All")>("All");
  const [selected, setSelected] = useState<PortfolioItem | null>(null);

  const filtered = useMemo(() => {
    const list = active === "All" ? portfolio : portfolio.filter((p) => p.category === active);
    return limit ? list.slice(0, limit) : list;
  }, [active, limit]);

  return (
    <div>
      {showFilters && (
        <div className="mb-10 flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className={cn(
                "rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                active === cat
                  ? "border-transparent bg-brand-gradient text-white"
                  : "border-white/10 text-frost-300 hover:border-white/20 hover:text-frost-100"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      <LayoutGroup>
        <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filtered.map((p) => (
              <motion.button
                layout
                key={p.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.4 }}
                whileHover={{ y: -6 }}
                onClick={() => setSelected(p)}
                className="group relative overflow-hidden rounded-xl2 border border-white/[0.08] text-left"
              >
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-ink-800">
                  <Image
                    src={p.image}
                    alt={`${p.title} — ${p.category} project screenshot`}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                    unoptimized
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/20 to-transparent opacity-80 transition-opacity group-hover:opacity-95" />
                  <div className="absolute inset-x-0 bottom-0 p-5">
                    <span className="eyebrow">{p.category}</span>
                    <h3 className="mt-1 font-display text-lg font-semibold text-frost-100">{p.title}</h3>
                  </div>
                  <div className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 opacity-0 backdrop-blur transition-opacity group-hover:opacity-100">
                    <ArrowUpRight className="h-4 w-4 text-white" />
                  </div>
                </div>
              </motion.button>
            ))}
          </AnimatePresence>
        </motion.div>
      </LayoutGroup>

      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[95] flex items-center justify-center bg-ink-950/80 p-6 backdrop-blur-sm"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              transition={{ duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card max-w-2xl overflow-hidden"
            >
              <div className="relative aspect-video w-full bg-ink-800">
                <Image
                  src={selected.image}
                  alt={`${selected.title} project preview`}
                  fill
                  className="object-cover"
                  unoptimized
                />
                <button
                  onClick={() => setSelected(null)}
                  aria-label="Close"
                  className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="p-7">
                <span className="eyebrow">{selected.category}</span>
                <h3 className="mt-2 font-display text-2xl font-bold text-frost-100">{selected.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-frost-400">{selected.description}</p>
                {selected.url && (
                  <a
                    href={selected.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary mt-6 text-sm"
                  >
                    Visit Live Site <ArrowUpRight className="h-4 w-4" />
                  </a>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
