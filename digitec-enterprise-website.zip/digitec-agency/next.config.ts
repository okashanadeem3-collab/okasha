import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "digitecenterprise.com",
      },
    ],
  },
  compress: true,
  poweredByHeader: false,
};

export default nextConfig;
