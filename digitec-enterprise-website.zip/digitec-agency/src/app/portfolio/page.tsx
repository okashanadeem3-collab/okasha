import type { Metadata } from "next";
import PortfolioGrid from "@/components/PortfolioGrid";
import Testimonials from "@/components/Testimonials";
import CTASection from "@/components/CTASection";

export const metadata: Metadata = {
  title: "Portfolio",
  description:
    "Explore Digitec Enterprise's portfolio of web design, branding, and e-commerce projects delivered for UK businesses across multiple industries.",
  alternates: { canonical: "/portfolio" },
};

export default function PortfolioPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-mesh-hero pt-40 pb-16">
        <div className="container-px">
          <p className="eyebrow mb-4">Our Work</p>
          <h1 className="max-w-2xl text-balance text-4xl font-bold leading-tight text-frost-100 md:text-6xl">
            Projects that speak for themselves
          </h1>
          <p className="mt-6 max-w-2xl text-balance text-lg text-frost-400">
            A selection of the websites, brands, and campaigns we&apos;ve built for clients across
            the UK and beyond. Filter by category or open a project for details.
          </p>
        </div>
      </section>

      <section className="section pt-8">
        <div className="container-px">
          <PortfolioGrid />
        </div>
      </section>

      <Testimonials />
      <CTASection />
    </>
  );
}
