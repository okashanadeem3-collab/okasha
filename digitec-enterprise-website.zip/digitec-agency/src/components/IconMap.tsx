import {
  Code2,
  TrendingUp,
  Sparkles,
  Share2,
  MousePointerClick,
  Palette,
  Clapperboard,
  LayoutTemplate,
  Smartphone,
  Target,
  type LucideIcon,
} from "lucide-react";

export const iconMap: Record<string, LucideIcon> = {
  Code2,
  TrendingUp,
  Sparkles,
  Share2,
  MousePointerClick,
  Palette,
  Clapperboard,
  LayoutTemplate,
  Smartphone,
  Target,
};
