"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function LoadingScreen() {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        const next = p + Math.random() * 24;
        return next >= 100 ? 100 : next;
      });
    }, 120);

    const timeout = setTimeout(() => setLoading(false), 1100);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-6 bg-ink-900"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
        >
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="font-display text-2xl font-bold tracking-tight text-frost-100"
          >
            Digitec<span className="gradient-text">.</span>
          </motion.div>
          <div className="h-[2px] w-40 overflow-hidden rounded-full bg-white/10">
            <motion.div
              className="h-full bg-brand-gradient"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>
          <span className="font-mono text-xs text-frost-400">
            {Math.floor(Math.min(progress, 100))}%
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
