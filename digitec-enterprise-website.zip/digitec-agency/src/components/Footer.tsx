import Link from "next/link";
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from "lucide-react";
import { company, navLinks, services } from "@/lib/data";
import Newsletter from "@/components/Newsletter";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/[0.06] bg-ink-950">
      <div className="container-px py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <Link href="/" className="font-display text-xl font-bold tracking-tight text-frost-100">
              Digitec<span className="gradient-text">.</span>
            </Link>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-frost-400">
              {company.description}
            </p>
            <div className="mt-6 flex gap-3">
              {[
                { href: company.social.facebook, icon: Facebook, label: "Facebook" },
                { href: company.social.twitter, icon: Twitter, label: "X / Twitter" },
                { href: company.social.instagram, icon: Instagram, label: "Instagram" },
              ].map(({ href, icon: Icon, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="glass flex h-10 w-10 items-center justify-center rounded-full text-frost-300 transition-colors hover:text-brand-light"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-display text-sm font-semibold text-frost-100">Quick Links</h3>
            <ul className="mt-4 space-y-3">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-frost-400 transition-colors hover:text-frost-100">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-semibold text-frost-100">Services</h3>
            <ul className="mt-4 space-y-3">
              {services.slice(0, 5).map((s) => (
                <li key={s.slug}>
                  <Link href="/services" className="text-sm text-frost-400 transition-colors hover:text-frost-100">
                    {s.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-semibold text-frost-100">Stay Updated</h3>
            <p className="mt-4 text-sm text-frost-400">
              Growth tips and case studies, roughly once a month. No spam.
            </p>
            <Newsletter />
          </div>
        </div>

        <div className="mt-14 grid gap-4 border-t border-white/[0.06] pt-8 text-sm text-frost-400 md:grid-cols-3">
          <a href={company.phoneHref} className="flex items-center gap-2 hover:text-frost-100">
            <Phone className="h-4 w-4 text-brand-light" /> {company.phone}
          </a>
          <a href={`mailto:${company.email}`} className="flex items-center gap-2 hover:text-frost-100">
            <Mail className="h-4 w-4 text-brand-light" /> {company.email}
          </a>
          <span className="flex items-center gap-2">
            <MapPin className="h-4 w-4 shrink-0 text-brand-light" /> {company.address}
          </span>
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-6 text-xs text-frost-500 md:flex-row">
          <p>© {new Date().getFullYear()} {company.name}. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="/privacy-policy" className="hover:text-frost-300">Privacy Policy</Link>
            <Link href="/terms-conditions" className="hover:text-frost-300">Terms &amp; Conditions</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
