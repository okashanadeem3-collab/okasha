import type { Metadata } from "next";
import { Check } from "lucide-react";
import { services } from "@/lib/data";
import { iconMap } from "@/components/IconMap";
import SectionHeading from "@/components/SectionHeading";
import PricingSection from "@/components/PricingSection";
import TechStack from "@/components/TechStack";
import IndustriesSection from "@/components/IndustriesSection";
import CTASection from "@/components/CTASection";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Website development, SEO, branding, social media marketing, PPC, graphic design, video editing, UI/UX, mobile app development and digital marketing strategy — all under one UK agency.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-mesh-hero pt-40 pb-20">
        <div className="container-px">
          <p className="eyebrow mb-4">What We Offer</p>
          <h1 className="max-w-2xl text-balance text-4xl font-bold leading-tight text-frost-100 md:text-6xl">
            Everything your brand needs to grow online
          </h1>
          <p className="mt-6 max-w-2xl text-balance text-lg text-frost-400">
            Our dedicated team of developers, designers, and strategists work with you at every
            step to deliver modern digital innovation and measurable online success.
          </p>
        </div>
      </section>

      <section className="section pt-0">
        <div className="container-px space-y-6">
          {services.map((s, i) => {
            const Icon = iconMap[s.icon];
            return (
              <div
                key={s.slug}
                id={s.slug}
                className="glass-card grid gap-8 p-8 md:grid-cols-[auto_1fr_auto] md:items-center md:p-10"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-gradient-soft text-brand-light md:h-16 md:w-16">
                  {Icon && <Icon className="h-7 w-7" />}
                </div>
                <div>
                  <span className="font-mono text-xs text-frost-500">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h2 className="mt-1 font-display text-2xl font-bold text-frost-100">{s.title}</h2>
                  <p className="mt-3 max-w-2xl text-sm leading-relaxed text-frost-400 md:text-base">
                    {s.description}
                  </p>
                </div>
                <ul className="space-y-2 md:min-w-[220px]">
                  {s.deliverables.map((d) => (
                    <li key={d} className="flex items-start gap-2 text-sm text-frost-300">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-signal" />
                      {d}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </section>

      <PricingSection />
      <IndustriesSection />
      <TechStack />
      <CTASection />
    </>
  );
}
