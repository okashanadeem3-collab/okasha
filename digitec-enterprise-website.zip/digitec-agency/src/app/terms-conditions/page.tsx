import type { Metadata } from "next";
import { company } from "@/lib/data";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: `Terms and conditions for ${company.name}.`,
  alternates: { canonical: "/terms-conditions" },
};

export default function TermsPage() {
  return (
    <section className="section pt-40">
      <div className="container-px prose prose-invert max-w-3xl prose-headings:font-display">
        <p className="eyebrow mb-4 not-prose">Legal</p>
        <h1>Terms &amp; Conditions</h1>
        <p className="text-frost-400">Last updated: July 2026</p>
        <p>
          This is a placeholder terms page for {company.name}. Replace it with your full terms of
          service, covering project scope, payment terms, intellectual property, and liability,
          before launch.
        </p>
        <h2>Services</h2>
        <p>
          All services are provided as agreed in an individual proposal or service agreement
          between {company.name} and the client.
        </p>
        <h2>Payment</h2>
        <p>
          Payment terms, including deposits and milestones, are outlined in each project&apos;s
          agreement.
        </p>
        <h2>Contact</h2>
        <p>
          Questions about these terms can be sent to{" "}
          <a href={`mailto:${company.email}`}>{company.email}</a>.
        </p>
      </div>
    </section>
  );
}
