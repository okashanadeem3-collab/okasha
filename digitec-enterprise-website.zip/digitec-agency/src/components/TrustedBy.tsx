import { clients } from "@/lib/data";

export default function TrustedBy() {
  const loop = [...clients, ...clients];

  return (
    <section className="border-y border-white/[0.06] bg-ink-950/60 py-10">
      <div className="container-px mb-4">
        <p className="text-center font-mono text-xs uppercase tracking-[0.25em] text-frost-500">
          Trusted by growing brands across the UK
        </p>
      </div>
      <div className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-ink-950 to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-ink-950 to-transparent" />
        <div className="flex w-max animate-marquee gap-12 whitespace-nowrap">
          {loop.map((name, i) => (
            <span
              key={`${name}-${i}`}
              className="font-display text-lg font-semibold text-frost-500/70"
            >
              {name}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
