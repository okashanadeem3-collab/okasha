import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import PortfolioGrid from "@/components/PortfolioGrid";

export default function PortfolioPreview() {
  return (
    <section className="section bg-ink-950/40">
      <div className="container-px">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="Selected Work"
            title="We've transformed businesses like yours — you're next"
            description="Explore recent projects across web design, branding, and e-commerce."
          />
          <Link href="/portfolio" className="btn-secondary shrink-0 text-sm">
            Full Portfolio <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-14">
          <PortfolioGrid limit={6} showFilters={false} />
        </div>
      </div>
    </section>
  );
}
