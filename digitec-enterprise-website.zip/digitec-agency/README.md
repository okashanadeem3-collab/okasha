# Digitec Enterprise — Agency Website

A premium, dark-themed marketing site for **Digitec Enterprise**, built with Next.js 15 (App Router),
React 19, TypeScript, Tailwind CSS, and Framer Motion.

Portfolio, testimonials, services, and company info were migrated and rewritten from the existing
site at [digitecenterprise.com](https://digitecenterprise.com); the visual design is entirely new.

## Tech Stack

- **Next.js 15** (App Router, Metadata API, `sitemap.ts` / `robots.ts`)
- **React 19** + **TypeScript** (strict mode)
- **Tailwind CSS** with a custom design-token theme (colors, gradients, animation keyframes)
- **Framer Motion** for scroll reveals, stagger animations, parallax, carousels, and page-load motion
- **lucide-react** for icons

## Getting Started

### 1. Install dependencies

```bash
npm install
```

> Requires Node.js 18.18 or newer.

### 2. Run the dev server

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000).

### 3. Type-check & lint

```bash
npm run type-check
npm run lint
```

### 4. Build for production

```bash
npm run build
npm run start
```

## Project Structure

```
src/
  app/
    layout.tsx          # Root layout: fonts, SEO metadata, JSON-LD, Navbar/Footer
    page.tsx             # Home
    about/page.tsx
    services/page.tsx
    portfolio/page.tsx
    contact/page.tsx
    privacy-policy/page.tsx
    terms-conditions/page.tsx
    not-found.tsx
    sitemap.ts
    robots.ts
    globals.css          # Design tokens, glassmorphism utilities, base styles
  components/             # Reusable UI: Hero, Navbar, Footer, PortfolioGrid, etc.
  lib/
    data.ts               # All content: services, portfolio, testimonials, pricing, FAQs
    utils.ts              # `cn()` className helper
```

## Content & CMS Notes

All copy and structured content (services, portfolio items, testimonials, pricing, FAQs, company
details) lives in **`src/lib/data.ts`**. Update that single file to change content across the
whole site — no component edits required for text/data changes.

Portfolio images currently reference the original site's uploaded screenshots. Before launch,
replace the URLs in `data.ts` with your own optimised assets in `/public/images/portfolio/` and
update `next.config.ts`'s `images.remotePatterns` accordingly (or remove `unoptimized` from the
`<Image>` calls in `PortfolioGrid.tsx` once local assets are used).

## Wiring Up the Contact Form

`src/components/ContactForm.tsx` is UI-complete but not connected to a backend. To make it
functional, pick one:

- **Formspree / Getform**: point the form's `action` at your endpoint, or `fetch()` it in
  `handleSubmit`.
- **Resend / Nodemailer via a Route Handler**: add `src/app/api/contact/route.ts` and call it from
  `handleSubmit` with `fetch("/api/contact", { method: "POST", body: JSON.stringify(data) })`.

The newsletter form in `src/components/Newsletter.tsx` follows the same pattern.

## SEO

- Per-page `metadata` (title, description, canonical) is set in each `page.tsx`.
- Open Graph & Twitter card images: replace `public/images/og-cover.svg` with a real 1200×630 image.
- Favicon: replace `public/favicon.svg` with your final mark (or add `app/icon.tsx` for a
  generated favicon).
- `sitemap.ts` and `robots.ts` generate `/sitemap.xml` and `/robots.txt` automatically — update the
  `baseUrl` constant in both files once you have a production domain.
- JSON-LD `MarketingAgency` structured data is injected in `layout.tsx`.

## Deploying to Vercel

1. Push this repository to GitHub (see below).
2. Go to [vercel.com/new](https://vercel.com/new) and import the repository.
3. Vercel auto-detects Next.js — no build settings need changing.
4. Add your production domain under **Settings → Domains** once deployed.
5. Every push to `main` redeploys automatically; pull requests get preview URLs.

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Digitec Enterprise website"
git branch -M main
git remote add origin https://github.com/<your-org>/<your-repo>.git
git push -u origin main
```

## Performance Notes

- Fonts are loaded via `next/font/google` (self-hosted, zero layout shift).
- Images use `next/image` with responsive `sizes` for portfolio cards.
- Animations respect `prefers-reduced-motion` (see `globals.css`).
- No client-side state libraries — Framer Motion + local component state only, keeping the bundle lean.

## License

Proprietary — © Digitec Enterprise. All rights reserved.
