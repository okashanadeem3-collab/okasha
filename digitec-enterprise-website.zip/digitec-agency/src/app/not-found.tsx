import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export default function NotFound() {
  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden bg-mesh-hero px-6 text-center">
      <div>
        <p className="font-display text-8xl font-bold gradient-text">404</p>
        <h1 className="mt-4 font-display text-2xl font-semibold text-frost-100 md:text-3xl">
          This page took a wrong turn
        </h1>
        <p className="mx-auto mt-3 max-w-md text-frost-400">
          The page you&apos;re looking for doesn&apos;t exist or may have moved. Let&apos;s get you
          back on track.
        </p>
        <Link href="/" className="btn-primary mt-8 inline-flex">
          Back to Home <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    </section>
  );
}
