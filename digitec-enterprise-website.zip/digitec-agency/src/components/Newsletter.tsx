"use client";

import { useState, FormEvent } from "react";
import { ArrowRight, Check } from "lucide-react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div className="mt-4 flex items-center gap-2 text-sm text-signal">
        <Check className="h-4 w-4" /> You&apos;re subscribed.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-4 flex items-center gap-2">
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@company.com"
        className="glass w-full rounded-full px-4 py-2.5 text-sm text-frost-100 placeholder:text-frost-500 focus:outline-none focus:ring-2 focus:ring-brand"
      />
      <button
        type="submit"
        aria-label="Subscribe"
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-white transition-transform hover:scale-105"
      >
        <ArrowRight className="h-4 w-4" />
      </button>
    </form>
  );
}
