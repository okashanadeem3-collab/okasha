"use client";

import { motion } from "framer-motion";
import { industries } from "@/lib/data";
import SectionHeading from "@/components/SectionHeading";

export default function IndustriesSection() {
  return (
    <section className="section">
      <div className="container-px">
        <SectionHeading eyebrow="Who We Serve" title="Industries we work with" />
        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {industries.map((ind, i) => (
            <motion.div
              key={ind}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              whileHover={{ y: -4 }}
              className="glass-card flex items-center justify-center px-6 py-8 text-center"
            >
              <span className="font-display text-sm font-medium text-frost-200 md:text-base">
                {ind}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
