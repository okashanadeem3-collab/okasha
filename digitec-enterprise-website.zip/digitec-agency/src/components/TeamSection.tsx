"use client";

import { motion } from "framer-motion";
import { Linkedin } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";

const team = [
  { role: "Founder & Strategy Lead" },
  { role: "Head of Web Development" },
  { role: "Lead Brand Designer" },
  { role: "SEO & Growth Manager" },
];

export default function TeamSection() {
  return (
    <section className="section">
      <div className="container-px">
        <SectionHeading
          eyebrow="Our People"
          title="The team behind the work"
          description="Profiles coming soon — this section is ready for real photos and bios as the team page goes live."
        />
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((member, i) => (
            <motion.div
              key={member.role}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="glass-card group overflow-hidden"
            >
              <div className="relative flex aspect-square items-center justify-center bg-gradient-to-br from-ink-700 to-ink-800">
                <span className="font-display text-4xl font-bold text-frost-500/30">
                  {member.role.split(" ").map((w) => w[0]).slice(0, 2).join("")}
                </span>
              </div>
              <div className="p-5">
                <p className="font-display text-sm font-semibold text-frost-100">Team Member</p>
                <p className="mt-1 text-xs text-frost-400">{member.role}</p>
                <div className="mt-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-frost-400 transition-colors group-hover:text-brand-light">
                  <Linkedin className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
