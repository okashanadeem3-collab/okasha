"use client";

import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, CheckCircle2 } from "lucide-react";

const fields = [
  { name: "name", label: "Full Name", type: "text", required: true },
  { name: "company", label: "Company", type: "text", required: false },
  { name: "email", label: "Email", type: "email", required: true },
  { name: "phone", label: "Phone", type: "tel", required: false },
];

export default function ContactForm() {
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("submitting");
    // Wire this up to your form handler / API route of choice.
    setTimeout(() => setStatus("success"), 900);
  }

  if (status === "success") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card flex flex-col items-center gap-4 p-10 text-center"
      >
        <CheckCircle2 className="h-12 w-12 text-signal" />
        <h3 className="font-display text-xl font-semibold text-frost-100">Message sent</h3>
        <p className="max-w-sm text-sm text-frost-400">
          Thanks for reaching out. Our team will get back to you within one business day.
        </p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="glass-card space-y-5 p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        {fields.map((f) => (
          <div key={f.name}>
            <label htmlFor={f.name} className="mb-2 block text-xs font-medium uppercase tracking-wider text-frost-400">
              {f.label} {f.required && <span className="text-brand-light">*</span>}
            </label>
            <input
              id={f.name}
              name={f.name}
              type={f.type}
              required={f.required}
              className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-frost-100 placeholder:text-frost-500 transition-colors focus:border-brand focus:outline-none"
              placeholder={f.label}
            />
          </div>
        ))}
      </div>

      <div>
        <label htmlFor="subject" className="mb-2 block text-xs font-medium uppercase tracking-wider text-frost-400">
          Subject
        </label>
        <input
          id="subject"
          name="subject"
          type="text"
          className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-frost-100 placeholder:text-frost-500 transition-colors focus:border-brand focus:outline-none"
          placeholder="What can we help with?"
        />
      </div>

      <div>
        <label htmlFor="message" className="mb-2 block text-xs font-medium uppercase tracking-wider text-frost-400">
          Message <span className="text-brand-light">*</span>
        </label>
        <textarea
          id="message"
          name="message"
          required
          rows={5}
          className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-frost-100 placeholder:text-frost-500 transition-colors focus:border-brand focus:outline-none"
          placeholder="Tell us a little about your project and goals..."
        />
      </div>

      <button type="submit" disabled={status === "submitting"} className="btn-primary w-full sm:w-auto">
        <AnimatePresence mode="wait">
          {status === "submitting" ? (
            <motion.span key="sub" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              Sending...
            </motion.span>
          ) : (
            <motion.span key="send" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
              Send Message <Send className="h-4 w-4" />
            </motion.span>
          )}
        </AnimatePresence>
      </button>
    </form>
  );
}
