"use client";

import { motion } from "framer-motion";
import { process } from "@/lib/data";
import SectionHeading from "@/components/SectionHeading";

export default function Process() {
  return (
    <section className="section bg-ink-950/40">
      <div className="container-px">
        <SectionHeading
          eyebrow="Our Process"
          title="How we work with UK businesses"
          description="A clear, repeatable process that keeps strategy, execution, and reporting aligned at every stage."
        />

        <div className="relative mt-16">
          <div className="absolute left-[15px] top-2 bottom-2 hidden w-px bg-gradient-to-b from-brand/60 via-violet/40 to-transparent md:block" />
          <div className="space-y-10 md:space-y-14">
            {process.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, x: -24 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                className="relative flex gap-6 md:gap-8"
              >
                <div className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-gradient font-mono text-xs font-semibold text-white">
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div className="glass-card flex-1 p-6">
                  <h3 className="font-display text-lg font-semibold text-frost-100">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-frost-400">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
