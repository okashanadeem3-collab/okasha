import type { Metadata } from "next";
import { Mail, Phone, MapPin, Clock, Facebook, Instagram, Twitter } from "lucide-react";
import { company } from "@/lib/data";
import ContactForm from "@/components/ContactForm";
import FAQAccordion from "@/components/FAQAccordion";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Digitec Enterprise for a free consultation on SEO, web development, branding, or social media marketing. UK-based team, fast response.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-mesh-hero pt-40 pb-20">
        <div className="container-px">
          <p className="eyebrow mb-4">Get In Touch</p>
          <h1 className="max-w-2xl text-balance text-4xl font-bold leading-tight text-frost-100 md:text-6xl">
            Let&apos;s talk business. But you first.
          </h1>
          <p className="mt-6 max-w-2xl text-balance text-lg text-frost-400">
            Tell us about your goals and we&apos;ll come back with a clear plan, no pressure, no jargon.
          </p>
        </div>
      </section>

      <section className="section pt-0">
        <div className="container-px grid gap-10 lg:grid-cols-[1fr_1.3fr]">
          <div className="space-y-5">
            <div className="glass-card p-6">
              <div className="flex items-start gap-4">
                <Phone className="mt-0.5 h-5 w-5 shrink-0 text-brand-light" />
                <div>
                  <p className="text-xs uppercase tracking-wider text-frost-500">Phone</p>
                  <a href={company.phoneHref} className="mt-1 block font-display text-lg font-semibold text-frost-100">
                    {company.phone}
                  </a>
                </div>
              </div>
            </div>
            <div className="glass-card p-6">
              <div className="flex items-start gap-4">
                <Mail className="mt-0.5 h-5 w-5 shrink-0 text-brand-light" />
                <div>
                  <p className="text-xs uppercase tracking-wider text-frost-500">Email</p>
                  <a href={`mailto:${company.email}`} className="mt-1 block font-display text-lg font-semibold text-frost-100">
                    {company.email}
                  </a>
                </div>
              </div>
            </div>
            <div className="glass-card p-6">
              <div className="flex items-start gap-4">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-brand-light" />
                <div>
                  <p className="text-xs uppercase tracking-wider text-frost-500">Head Office</p>
                  <p className="mt-1 text-sm leading-relaxed text-frost-200">{company.address}</p>
                </div>
              </div>
            </div>
            <div className="glass-card p-6">
              <div className="flex items-start gap-4">
                <Clock className="mt-0.5 h-5 w-5 shrink-0 text-brand-light" />
                <div className="w-full">
                  <p className="text-xs uppercase tracking-wider text-frost-500">Business Hours</p>
                  <div className="mt-2 space-y-1">
                    {company.hours.map((h) => (
                      <div key={h.day} className="flex justify-between text-sm text-frost-300">
                        <span>{h.day}</span>
                        <span className="text-frost-400">{h.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              {[
                { href: company.social.facebook, icon: Facebook, label: "Facebook" },
                { href: company.social.twitter, icon: Twitter, label: "X / Twitter" },
                { href: company.social.instagram, icon: Instagram, label: "Instagram" },
              ].map(({ href, icon: Icon, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="glass flex h-11 w-11 items-center justify-center rounded-full text-frost-300 transition-colors hover:text-brand-light"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <ContactForm />
        </div>
      </section>

      <section className="container-px pb-20">
        <div className="glass-card overflow-hidden">
          <iframe
            title="Digitec Enterprise office location"
            src="https://www.google.com/maps?q=Office+688+58+Peregrine+Road+Hainault+Ilford+Essex+IG6+3SZ&output=embed"
            className="h-[380px] w-full grayscale"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

      <FAQAccordion />
    </>
  );
}
