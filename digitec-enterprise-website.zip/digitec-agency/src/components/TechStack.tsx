import { technologies } from "@/lib/data";
import SectionHeading from "@/components/SectionHeading";

export default function TechStack() {
  return (
    <section className="section bg-ink-950/40">
      <div className="container-px">
        <SectionHeading align="center" eyebrow="Our Toolkit" title="Technologies we use" />
        <div className="mt-12 flex flex-wrap items-center justify-center gap-3">
          {technologies.map((tech) => (
            <span
              key={tech}
              className="glass rounded-full px-5 py-2.5 text-sm font-medium text-frost-300"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
