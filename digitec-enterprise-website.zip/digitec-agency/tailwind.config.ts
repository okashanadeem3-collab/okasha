import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    container: {
      center: true,
      padding: "1.5rem",
      screens: { "2xl": "1320px" },
    },
    extend: {
      colors: {
        ink: {
          950: "#07080C",
          900: "#0A0B10",
          800: "#10131C",
          700: "#171B27",
          600: "#202635",
        },
        frost: {
          100: "#F5F6FA",
          200: "#E4E7EF",
          300: "#C7CCDA",
          400: "#8B92A6",
          500: "#5C6377",
        },
        brand: {
          DEFAULT: "#3E6FF5",
          light: "#6C93FF",
          dark: "#2851D6",
        },
        violet: {
          DEFAULT: "#7C5CFF",
          light: "#9C82FF",
          dark: "#5B3FE0",
        },
        signal: "#3EF5C5",
      },
      fontFamily: {
        display: ["var(--font-poppins)", "sans-serif"],
        body: ["var(--font-inter)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "mesh-hero":
          "radial-gradient(60% 50% at 15% 10%, rgba(62,111,245,0.28) 0%, rgba(62,111,245,0) 60%), radial-gradient(50% 45% at 85% 20%, rgba(124,92,255,0.24) 0%, rgba(124,92,255,0) 60%), radial-gradient(60% 60% at 50% 100%, rgba(62,245,197,0.10) 0%, rgba(62,245,197,0) 60%)",
        "brand-gradient": "linear-gradient(135deg, #3E6FF5 0%, #7C5CFF 100%)",
        "brand-gradient-soft":
          "linear-gradient(135deg, rgba(62,111,245,0.15) 0%, rgba(124,92,255,0.15) 100%)",
      },
      boxShadow: {
        glass: "0 8px 32px rgba(0,0,0,0.35)",
        glow: "0 0 40px rgba(62,111,245,0.35)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-16px)" },
        },
        "spin-slow": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(360deg)" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        "spin-slow": "spin-slow 18s linear infinite",
        marquee: "marquee 28s linear infinite",
      },
    },
  },
  plugins: [require("@tailwindcss/typography")],
};

export default config;
