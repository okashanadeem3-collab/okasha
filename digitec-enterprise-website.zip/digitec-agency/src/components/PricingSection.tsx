"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import Link from "next/link";
import { pricingPlans } from "@/lib/data";
import SectionHeading from "@/components/SectionHeading";
import { cn } from "@/lib/utils";

const categories = ["Website Development", "SEO", "Social Media"];

export default function PricingSection() {
  const [active, setActive] = useState(categories[0]);

  const plans = useMemo(
    () => pricingPlans.filter((p) => p.category === active),
    [active]
  );

  return (
    <section className="section">
      <div className="container-px">
        <SectionHeading
          align="center"
          eyebrow="Pricing"
          title="Digital marketing packages designed for every business"
          description="Transparent starting prices across our core services. Every plan can be tailored to your goals."
        />

        <div className="mx-auto mt-10 flex w-fit gap-1 rounded-full border border-white/10 p-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className={cn(
                "rounded-full px-5 py-2 text-sm font-medium transition-colors",
                active === cat ? "bg-brand-gradient text-white" : "text-frost-400 hover:text-frost-100"
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className={cn(
                "glass-card relative flex flex-col p-8",
                plan.popular && "border-brand/50 ring-1 ring-brand/30"
              )}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-gradient px-4 py-1 text-xs font-semibold text-white">
                  Most Popular
                </span>
              )}
              <h3 className="font-display text-lg font-semibold text-frost-100">{plan.name}</h3>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-bold text-frost-100">{plan.price}</span>
                {plan.originalPrice && (
                  <span className="text-sm text-frost-500 line-through">{plan.originalPrice}</span>
                )}
              </div>
              <p className="mt-1 text-xs text-frost-500">{plan.note}</p>

              <ul className="mt-6 flex-1 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-frost-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-signal" />
                    {f}
                  </li>
                ))}
              </ul>

              <Link
                href="/contact"
                className={cn(
                  "mt-8 rounded-full px-6 py-3 text-center text-sm font-semibold transition-transform hover:scale-[1.02]",
                  plan.popular ? "bg-brand-gradient text-white" : "glass text-frost-100"
                )}
              >
                Get Started
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
