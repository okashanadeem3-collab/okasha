"use client";

import { useEffect, useRef } from "react";
import { useInView, useMotionValue, animate } from "framer-motion";

export default function AnimatedCounter({
  value,
  suffix = "",
  duration = 1.8,
}: {
  value: number;
  suffix?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const motionValue = useMotionValue(0);
  const isDecimal = !Number.isInteger(value);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(motionValue, value, { duration, ease: "easeOut" });
    return () => controls.stop();
  }, [inView, value, duration, motionValue]);

  useEffect(() => {
    const unsub = motionValue.on("change", (latest) => {
      if (ref.current) {
        ref.current.textContent = isDecimal ? latest.toFixed(1) : Math.floor(latest).toString();
      }
    });
    return unsub;
  }, [motionValue, isDecimal]);

  return (
    <span className="inline-flex items-baseline font-display">
      <span ref={ref}>0</span>
      <span>{suffix}</span>
    </span>
  );
}
