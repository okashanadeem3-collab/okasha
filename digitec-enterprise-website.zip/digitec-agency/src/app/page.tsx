import type { Metadata } from "next";
import Hero from "@/components/Hero";
import TrustedBy from "@/components/TrustedBy";
import ServicesOverview from "@/components/ServicesOverview";
import Stats from "@/components/Stats";
import PortfolioPreview from "@/components/PortfolioPreview";
import Testimonials from "@/components/Testimonials";
import Process from "@/components/Process";
import BlogPreview from "@/components/BlogPreview";
import FAQAccordion from "@/components/FAQAccordion";
import CTASection from "@/components/CTASection";

export const metadata: Metadata = {
  title: "UK Digital Marketing Agency | Web, SEO, Branding & Social",
  description:
    "Digitec Enterprise helps UK businesses grow online through SEO, PPC, branding, web development and social media marketing built on strategy and measurable results.",
  alternates: { canonical: "/" },
};

export default function Home() {
  return (
    <>
      <Hero />
      <TrustedBy />
      <ServicesOverview />
      <Stats />
      <PortfolioPreview />
      <Process />
      <Testimonials />
      <BlogPreview />
      <FAQAccordion />
      <CTASection />
    </>
  );
}
