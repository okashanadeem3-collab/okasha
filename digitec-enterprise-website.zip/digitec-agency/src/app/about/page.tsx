import type { Metadata } from "next";
import { Sparkles, Wallet, Users, Clock4 } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import TrustedBy from "@/components/TrustedBy";
import Stats from "@/components/Stats";
import TeamSection from "@/components/TeamSection";
import CTASection from "@/components/CTASection";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Digitec Enterprise is a UK digital marketing agency built on strategy, creativity, and measurable results. Learn our story, mission, and why UK businesses choose us.",
  alternates: { canonical: "/about" },
};

const whyChooseUs = [
  { icon: Sparkles, title: "Creative Excellence", description: "Our team of experts brings creativity and innovation to every project." },
  { icon: Wallet, title: "Affordable Solutions", description: "High-quality services delivered at genuinely competitive prices." },
  { icon: Users, title: "Client-Centric Approach", description: "Your satisfaction is our priority — we work closely with you at every stage." },
  { icon: Clock4, title: "Timely Delivery", description: "We respect your deadlines and deliver on time without compromising quality." },
];

export default function AboutPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-mesh-hero pt-40 pb-24">
        <div className="container-px">
          <p className="eyebrow mb-4">About Us</p>
          <h1 className="max-w-3xl text-balance text-4xl font-bold leading-tight text-frost-100 md:text-6xl">
            Empowering brands in the digital world
          </h1>
          <p className="mt-6 max-w-2xl text-balance text-lg text-frost-400">
            At Digitec Enterprise, we&apos;re more than a digital marketing agency — we&apos;re your
            growth partners. We combine creativity, strategy, and technology to help UK businesses
            build a stronger online presence and grow with confidence.
          </p>
        </div>
      </section>

      <TrustedBy />

      <section className="section">
        <div className="container-px grid gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow="Our Story"
              title="Transforming businesses in the digital age"
              description="At Digitec Enterprise, we are more than just a design and development agency — we are innovators, problem solvers, and brand builders. Our mission is to help businesses establish a strong digital presence through expert branding, cutting-edge web solutions, and strategic marketing."
            />
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="glass-card p-7">
              <h3 className="font-display text-lg font-semibold text-frost-100">Our Mission</h3>
              <p className="mt-3 text-sm leading-relaxed text-frost-400">
                To give UK businesses the strategy, design, and technology they need to grow online,
                with results that are measured, not just admired.
              </p>
            </div>
            <div className="glass-card p-7">
              <h3 className="font-display text-lg font-semibold text-frost-100">Our Vision</h3>
              <p className="mt-3 text-sm leading-relaxed text-frost-400">
                To be the digital growth partner UK businesses trust first — known for creativity,
                clarity, and consistent long-term results.
              </p>
            </div>
            <div className="glass-card p-7 sm:col-span-2">
              <h3 className="font-display text-lg font-semibold text-frost-100">What We Specialise In</h3>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                <div>
                  <p className="font-medium text-frost-200">Technology</p>
                  <p className="mt-1 text-xs text-frost-400">Sleek, high-performance sites and apps for startups and software companies.</p>
                </div>
                <div>
                  <p className="font-medium text-frost-200">E-commerce</p>
                  <p className="mt-1 text-xs text-frost-400">Custom online stores and engaging brand identities that convert.</p>
                </div>
                <div>
                  <p className="font-medium text-frost-200">Corporate</p>
                  <p className="mt-1 text-xs text-frost-400">Professional websites built for credibility and lead generation.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Stats />

      <section className="section">
        <div className="container-px">
          <SectionHeading align="center" eyebrow="Why Digitec" title="Why choose Digitec Enterprise?" />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {whyChooseUs.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.title} className="glass-card p-7 text-center">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-gradient-soft text-brand-light">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="font-display text-base font-semibold text-frost-100">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-frost-400">{item.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <TeamSection />
      <CTASection />
    </>
  );
}
