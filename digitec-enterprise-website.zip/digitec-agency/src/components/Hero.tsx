"use client";

import { useRef } from "react";
import Link from "next/link";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { ArrowUpRight, Play } from "lucide-react";
import GradientRevealText from "@/components/GradientRevealText";

export default function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 60, damping: 20 });
  const sy = useSpring(my, { stiffness: 60, damping: 20 });
  const orb1X = useTransform(sx, (v) => v * 0.5);
  const orb1Y = useTransform(sy, (v) => v * 0.5);
  const orb2X = useTransform(sx, (v) => v * -0.35);
  const orb2Y = useTransform(sy, (v) => v * -0.35);

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    mx.set((e.clientX - rect.left - rect.width / 2) / 8);
    my.set((e.clientY - rect.top - rect.height / 2) / 8);
  }

  return (
    <section
      ref={ref}
      onMouseMove={handleMouseMove}
      className="relative flex min-h-screen items-center overflow-hidden bg-mesh-hero pt-32 pb-20"
    >
      <motion.div
        style={{ x: orb1X, y: orb1Y }}
        className="pointer-events-none absolute -top-24 left-[8%] h-72 w-72 animate-float rounded-full bg-brand/20 blur-3xl"
      />
      <motion.div
        style={{ x: orb2X, y: orb2Y }}
        className="pointer-events-none absolute bottom-0 right-[10%] h-96 w-96 animate-float rounded-full bg-violet/20 blur-3xl [animation-delay:2s]"
      />

      <div className="container-px relative w-full">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="glass mb-8 inline-flex items-center gap-2 rounded-full px-4 py-2"
        >
          <span className="h-2 w-2 rounded-full bg-signal" />
          <span className="font-mono text-xs uppercase tracking-widest text-frost-300">
            Trusted UK Digital Marketing Agency
          </span>
        </motion.div>

        <h1 className="max-w-4xl text-balance text-5xl font-bold leading-[1.05] tracking-tight text-frost-100 sm:text-6xl lg:text-7xl">
          <motion.span
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="block"
          >
            Growth, engineered
          </motion.span>
          <motion.span
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.22 }}
            className="gradient-text block"
          >
            not guessed at.
          </motion.span>
        </h1>

        <div className="mt-8 max-w-xl">
          <GradientRevealText
            text="We help UK businesses reach more customers and boost online visibility through SEO, PPC, branding, and web development built on strategy and measurable results."
            className="text-lg leading-relaxed md:text-xl"
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <Link href="/contact" className="btn-primary">
            Start Your Project <ArrowUpRight className="h-4 w-4" />
          </Link>
          <Link href="/portfolio" className="btn-secondary">
            <Play className="h-4 w-4" /> View Our Work
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
