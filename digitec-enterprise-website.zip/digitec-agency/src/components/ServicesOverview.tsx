"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { services } from "@/lib/data";
import { iconMap } from "@/components/IconMap";
import SectionHeading from "@/components/SectionHeading";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};

const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function ServicesOverview() {
  return (
    <section className="section">
      <div className="container-px">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="What We Offer"
            title="Professional marketing services built to grow your business"
            description="From first click to final conversion, our team covers every discipline your brand needs to grow online."
          />
          <Link href="/services" className="btn-secondary shrink-0 text-sm">
            All Services <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.15 }}
          className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {services.slice(0, 6).map((s) => {
            const Icon = iconMap[s.icon];
            return (
              <motion.div
                key={s.slug}
                variants={item}
                whileHover={{ y: -6 }}
                className="glass-card group relative overflow-hidden p-7"
              >
                <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-brand-gradient opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-30" />
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-gradient-soft text-brand-light">
                  {Icon && <Icon className="h-6 w-6" />}
                </div>
                <h3 className="font-display text-lg font-semibold text-frost-100">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-frost-400">{s.short}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
