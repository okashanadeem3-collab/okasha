"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

export default function CTASection() {
  return (
    <section className="container-px py-20">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="relative overflow-hidden rounded-xl2 bg-brand-gradient px-8 py-16 text-center md:px-16"
      >
        <div className="pointer-events-none absolute -top-16 -left-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-16 -right-16 h-64 w-64 rounded-full bg-ink-950/20 blur-3xl" />
        <h2 className="text-balance font-display text-3xl font-bold text-white md:text-4xl lg:text-5xl">
          Ready to grow your business online?
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-balance text-white/85">
          Tell us about your goals and we&apos;ll put together a plan built around them, no obligation.
        </p>
        <Link
          href="/contact"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-sm font-semibold text-ink-900 transition-transform hover:scale-105"
        >
          Get a Free Consultation <ArrowUpRight className="h-4 w-4" />
        </Link>
      </motion.div>
    </section>
  );
}
