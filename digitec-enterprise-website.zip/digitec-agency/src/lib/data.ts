// Content migrated & rewritten from https://digitecenterprise.com
// Portfolio, testimonials, services and company info are sourced from the
// live site; copy has been rewritten for the new premium brand voice.

export const company = {
  name: "Digitec Enterprise",
  tagline: "Engineered Growth for Ambitious UK Brands",
  description:
    "Digitec Enterprise is a UK digital marketing agency helping businesses grow online through results-driven SEO, PPC, branding, and web development. We combine strategy, design, and technology into campaigns built to be measured, not just admired.",
  phone: "+44 20 8638 8301",
  phoneHref: "tel:442086388301",
  email: "info@digitecenterprise.com",
  address: "Office 688, 58 Peregrine Road, Hainault, Ilford, Essex, IG6 3SZ, United Kingdom",
  social: {
    facebook: "https://www.facebook.com/digitecenterpriseltd",
    twitter: "https://x.com/Digitech_2022",
    instagram: "https://www.instagram.com/digitech_enterpriselimited/",
  },
  hours: [
    { day: "Monday – Friday", time: "9:00 AM – 6:00 PM" },
    { day: "Saturday", time: "10:00 AM – 2:00 PM" },
    { day: "Sunday", time: "Closed" },
  ],
};

export const stats = [
  { label: "Projects Delivered", value: 250, suffix: "+" },
  { label: "Happy Clients", value: 180, suffix: "+" },
  { label: "Average Client Rating", value: 4.9, suffix: "/5" },
  { label: "Years of Experience", value: 6, suffix: "+" },
];

export type Service = {
  slug: string;
  title: string;
  short: string;
  description: string;
  icon: string;
  deliverables: string[];
};

export const services: Service[] = [
  {
    slug: "website-development",
    title: "Website Development",
    short: "Fast, responsive websites engineered to convert.",
    description:
      "We design and build high-performing, responsive websites that turn visitors into customers. Every build is optimised for speed, accessibility, and search from day one.",
    icon: "Code2",
    deliverables: ["Custom responsive design", "Headless & CMS builds", "E-commerce", "Speed & Core Web Vitals tuning"],
  },
  {
    slug: "seo",
    title: "SEO",
    short: "Search visibility built on strategy, not shortcuts.",
    description:
      "Our SEO programmes combine technical audits, on-page optimisation, and authoritative content to move your brand up the rankings and keep it there.",
    icon: "TrendingUp",
    deliverables: ["Technical & on-page audit", "Keyword strategy", "Content & backlinks", "Monthly performance reporting"],
  },
  {
    slug: "branding",
    title: "Branding",
    short: "Identities that make businesses instantly recognisable.",
    description:
      "From naming to visual identity systems, we help brands define who they are and show up consistently everywhere their audience looks.",
    icon: "Sparkles",
    deliverables: ["Brand strategy", "Logo & visual identity", "Brand guidelines", "Collateral design"],
  },
  {
    slug: "social-media-marketing",
    title: "Social Media Marketing",
    short: "Content and campaigns that build loyal communities.",
    description:
      "We plan, create, and manage social content and paid campaigns that keep your brand active where your audience already spends time.",
    icon: "Share2",
    deliverables: ["Content calendars", "Paid social campaigns", "Community management", "Analytics & reporting"],
  },
  {
    slug: "ppc",
    title: "Pay-Per-Click Advertising",
    short: "Instant, measurable traffic that pays for itself.",
    description:
      "Our PPC specialists build and optimise campaigns across Google and social platforms, maximising ROI and converting clicks into customers.",
    icon: "MousePointerClick",
    deliverables: ["Campaign strategy", "Ad creative & copy", "Bid & budget optimisation", "Conversion tracking"],
  },
  {
    slug: "graphic-design",
    title: "Graphic Design",
    short: "Visuals that stop the scroll and hold attention.",
    description:
      "Our design team produces logos, banners, and campaign visuals engineered to capture attention and reinforce brand identity across every channel.",
    icon: "Palette",
    deliverables: ["Logo & print design", "Social & ad creative", "Packaging design", "Presentation design"],
  },
  {
    slug: "video-editing",
    title: "Video Editing & Animation",
    short: "2D/3D animation and edits that tell your story.",
    description:
      "From explainer animations to polished product videos, we edit and animate content that keeps audiences watching and sharing.",
    icon: "Clapperboard",
    deliverables: ["2D & 3D animation", "Social video edits", "Motion graphics", "Product & promo videos"],
  },
  {
    slug: "ui-ux-design",
    title: "UI/UX Design",
    short: "Interfaces designed around real user behaviour.",
    description:
      "We design intuitive, research-backed interfaces for web and mobile that reduce friction and guide users toward conversion.",
    icon: "LayoutTemplate",
    deliverables: ["User research & wireframes", "Interactive prototypes", "Design systems", "Usability testing"],
  },
  {
    slug: "mobile-app-development",
    title: "Mobile App Development",
    short: "Seamless native & cross-platform apps.",
    description:
      "We design and build Android and iOS apps that boost engagement and deliver a smooth, reliable user experience from launch onward.",
    icon: "Smartphone",
    deliverables: ["iOS & Android builds", "Cross-platform development", "App Store optimisation", "Post-launch support"],
  },
  {
    slug: "digital-marketing",
    title: "Digital Marketing Strategy",
    short: "Joined-up strategy across every channel you run.",
    description:
      "We build integrated digital marketing strategies that align SEO, paid, content, and social into one measurable growth plan.",
    icon: "Target",
    deliverables: ["Market & competitor research", "Channel strategy", "Content marketing", "Performance dashboards"],
  },
];

export type PortfolioCategory = "Web Design" | "Branding" | "Social Media" | "E-commerce";

export type PortfolioItem = {
  title: string;
  category: PortfolioCategory;
  description: string;
  url?: string;
  image: string;
};

export const portfolio: PortfolioItem[] = [
  {
    title: "Design Maison",
    category: "Web Design",
    description: "A refined interior-design studio site pairing warm imagery with a clean booking journey.",
    url: "https://www.designmaison.uk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/1-2.png",
  },
  {
    title: "Farooqi Enterprises",
    category: "Web Design",
    description: "Corporate site for an international trading company, built for credibility and lead capture.",
    url: "https://farooqienterprises.com/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/farooqiwebsite.jpg",
  },
  {
    title: "Markhor Pet Treats",
    category: "E-commerce",
    description: "Playful e-commerce storefront for a pet-treats brand, optimised for mobile conversion.",
    url: "https://markhorpettreats.com/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/markhor.jpg",
  },
  {
    title: "ARK Mortgages",
    category: "Web Design",
    description: "A trust-forward financial services site with clear calculators and enquiry flows.",
    url: "https://arkmortgages.co.uk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/arkmorkages-1.jpg",
  },
  {
    title: "Bump to Baby Pram",
    category: "E-commerce",
    description: "Soft, parent-friendly retail experience for a premium pram and nursery brand.",
    url: "https://bumptobabypram.co.uk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/1-1.png",
  },
  {
    title: "The Toys Arena",
    category: "E-commerce",
    description: "Vibrant, high-energy storefront built to match a bold, kid-first retail brand.",
    url: "https://thetoysarena.pk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/WhatsApp-Image-2025-06-05-at-6.40.11-PM.jpeg",
  },
  {
    title: "AM Street Cars",
    category: "Web Design",
    description: "A local transport service site focused on fast quotes and easy booking.",
    url: "https://amstreetcars.com/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/1-3.png",
  },
  {
    title: "ASQ",
    category: "Web Design",
    description: "A sharp, professional services website with a modern service-led structure.",
    url: "https://asqsl.co.uk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/1-4.png",
  },
  {
    title: "Apex Artistic Generations",
    category: "Branding",
    description: "Full identity and web presence for a creative studio, anchored by a bold gradient mark.",
    url: "https://apexartisticgenerations.com/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/aagenerations.jpg",
  },
  {
    title: "Snuggles Dog Grooming",
    category: "Web Design",
    description: "A friendly local-service site built around bookings and customer trust signals.",
    url: "https://www.snugglesdoggrooming.co.uk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/Screenshot-2025-10-14-024946.png",
  },
  {
    title: "Lee Marley",
    category: "Web Design",
    description: "A polished corporate presence for an established construction and services brand.",
    url: "https://www.leemarley.com/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/Screenshot-2025-10-14-025211.png",
  },
  {
    title: "South Side Creations",
    category: "Branding",
    description: "Brand and web design for a creative collective, built to showcase a growing portfolio.",
    url: "https://southsidecreations.co.uk/",
    image: "https://digitecenterprise.com/wp-content/uploads/2025/02/Screenshot-2025-10-14-030632-1.png",
  },
];

export type Testimonial = {
  name: string;
  role: string;
  quote: string;
  rating: number;
};

export const testimonials: Testimonial[] = [
  {
    name: "Laura W.",
    role: "E-commerce Business",
    quote:
      "Digitec completely changed how my online store performs. Their digital marketing strategies helped increase traffic and sales within just a few months. The team is easy to work with and always available for support.",
    rating: 5,
  },
  {
    name: "Mark R.",
    role: "Real Estate Agency",
    quote:
      "We partnered with Digitec to improve our website and online presence, and the results have been great. Our search visibility and leads have gone up noticeably. They really understand what small businesses need.",
    rating: 5,
  },
  {
    name: "Sophie D.",
    role: "Café Owner",
    quote:
      "Working with Digitec was one of the best choices for my café. Their social media marketing and ad campaigns brought in new customers and helped us build a stronger local presence.",
    rating: 5,
  },
];

export const clients = [
  "Educate", "ARK Mortgages", "HKUST", "Bump to Baby", "Art of Soccer",
  "Home Solutions", "Farooqi Enterprises", "Vintage Land Rover Tours",
  "Markhor Pet Treats", "Apex Artistic Generations", "Toys Arena",
  "Graig Farm Organics", "Stitchy Tec", "Creovate",
];

export const process = [
  { title: "Understanding Your Goals", description: "We start by learning your business, audience, and what success looks like, so every decision has a clear direction." },
  { title: "Research & Insight", description: "We study your market, competitors, and audience behaviour to uncover real opportunities for growth." },
  { title: "Planning & Strategy", description: "We build a focused plan covering content, design, marketing, and performance tracking." },
  { title: "Creation & Execution", description: "Our team brings the strategy to life through design, content, and campaigns built to connect and convert." },
  { title: "Review & Optimisation", description: "We track performance closely, refining what works and improving what doesn't." },
  { title: "Reporting & Support", description: "You stay informed with clear reporting and ongoing support as your growth continues." },
];

export type PricingPlan = {
  name: string;
  category: string;
  price: string;
  originalPrice?: string;
  note: string;
  popular?: boolean;
  features: string[];
};

export const pricingPlans: PricingPlan[] = [
  {
    name: "Silver",
    category: "Website Development",
    price: "£399.99",
    originalPrice: "£899.98",
    note: "40% deposit to begin",
    features: [
      "Custom responsive design",
      "4–10 pages",
      "Image optimisation for fast loading",
      "Custom 404 & Google Maps integration",
      "Optional blog setup",
    ],
  },
  {
    name: "Gold",
    category: "Website Development",
    price: "£599.99",
    originalPrice: "£1199.98",
    note: "40% deposit to begin",
    popular: true,
    features: [
      "4–15 pages, W3C-certified HTML",
      "1 month web support + 1 month SEO",
      "Free logo design (optional)",
      "1 year SSL, 6 months hosting & domain",
      "Optional AI chatbot & content writing",
    ],
  },
  {
    name: "Platinum",
    category: "Website Development",
    price: "£799.99",
    originalPrice: "£1599.98",
    note: "40% deposit to begin",
    features: [
      "4–20 pages, fully responsive",
      "2 months web support + 2 months SEO",
      "Free logo design (optional)",
      "1 year SSL, hosting & domain",
      "Optional AI chatbot & content writing",
    ],
  },
  {
    name: "Startup",
    category: "SEO",
    price: "£199.00",
    originalPrice: "£400.00",
    note: "4-month minimum contract",
    features: [
      "Focused keyword research",
      "On-page SEO for up to 5 pages",
      "Site speed & meta optimisation",
      "Sitemap & robots setup",
      "Monthly performance report",
    ],
  },
  {
    name: "Scaling",
    category: "SEO",
    price: "£300.00",
    originalPrice: "£700.00",
    note: "4-month minimum contract",
    popular: true,
    features: [
      "Long-tail keyword targeting",
      "On-page SEO for up to 15 pages",
      "Quality backlink outreach",
      "Competitor & niche analysis",
      "4 months technical support",
    ],
  },
  {
    name: "Venture",
    category: "SEO",
    price: "£500.00",
    originalPrice: "£1000.00",
    note: "4-month minimum contract",
    features: [
      "Advanced backlink strategy",
      "Full site audit & roadmap",
      "Priority ranking strategy",
      "Monthly SERP monitoring",
      "Dedicated account manager",
    ],
  },
  {
    name: "Basic",
    category: "Social Media",
    price: "£349.99",
    originalPrice: "£799.00",
    note: "Min. ads budget £300",
    features: [
      "8 posts / reels per month",
      "2 platforms (Facebook & Instagram)",
      "Audience research & captioning",
      "Trending hashtag strategy",
      "Monthly performance report",
    ],
  },
  {
    name: "Standard",
    category: "Social Media",
    price: "£649.99",
    originalPrice: "£1300.00",
    note: "Min. ads budget £1000",
    popular: true,
    features: [
      "15 posts / reels / ads per month",
      "3 platforms, daily posting",
      "Ad strategy & campaign setup",
      "Organic growth strategy",
      "Detailed competitor analysis",
    ],
  },
  {
    name: "Premium",
    category: "Social Media",
    price: "£1149.99",
    originalPrice: "£2300.00",
    note: "Min. ads budget £1500",
    features: [
      "25+ posts / reels / ads per month",
      "All major platforms",
      "Influencer collaboration strategy",
      "Advanced ads targeting",
      "Monthly growth consultation",
    ],
  },
];

export const faqs = [
  {
    q: "What does a digital marketing agency do?",
    a: "A digital marketing agency helps businesses grow online through strategies like SEO, PPC, social media marketing, web design, and content creation. At Digitec Enterprise, we build customised plans to improve your visibility and generate real results.",
  },
  {
    q: "Why should I hire a digital marketing company in the UK?",
    a: "Hiring a UK-based digital marketing company ensures you work with experts who understand your local audience, industry trends, and market behaviour, helping your business reach the right people faster.",
  },
  {
    q: "How much do digital marketing services cost?",
    a: "The cost depends on your goals, the services you need, and your industry. Whether you need SEO, PPC, or complete online marketing, we create flexible plans that fit your budget with no hidden fees.",
  },
  {
    q: "How long does it take to see results from digital marketing?",
    a: "Results vary based on strategy. Some services like PPC deliver instant results, while SEO and content marketing take a few months to build long-term growth and visibility.",
  },
  {
    q: "What industries do you work with?",
    a: "We work with a wide range of UK businesses, from small startups and e-commerce brands to service-based companies and established enterprises.",
  },
  {
    q: "Do you offer social media marketing services?",
    a: "Yes, we manage campaigns that increase engagement, build brand awareness, and help businesses connect with their audience on Facebook, Instagram, LinkedIn, and TikTok.",
  },
  {
    q: "Can you help improve my website's Google ranking?",
    a: "Absolutely. Our SEO experts use keyword optimisation, technical SEO, and quality content to improve your rankings and attract more organic traffic.",
  },
  {
    q: "Do you offer website design and development services?",
    a: "Yes, our team designs and builds responsive, user-friendly websites that align with your brand and marketing goals while improving conversions.",
  },
];

export const industries = [
  "E-commerce", "Real Estate", "Education", "Hospitality & Food",
  "Healthcare", "Professional Services", "Retail", "Technology & SaaS",
];

export const technologies = [
  "Next.js", "React", "TypeScript", "Tailwind CSS", "Figma",
  "WordPress", "Shopify", "Google Ads", "Meta Ads", "GA4",
];

export const navLinks = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Contact", href: "/contact" },
];
