import type { Metadata } from "next";
import { company } from "@/lib/data";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `Privacy policy for ${company.name}.`,
  alternates: { canonical: "/privacy-policy" },
};

export default function PrivacyPolicyPage() {
  return (
    <section className="section pt-40">
      <div className="container-px prose prose-invert max-w-3xl prose-headings:font-display">
        <p className="eyebrow mb-4 not-prose">Legal</p>
        <h1>Privacy Policy</h1>
        <p className="text-frost-400">Last updated: July 2026</p>
        <p>
          {company.name} respects your privacy. This page outlines a placeholder policy — replace
          it with your full privacy policy covering data collection, cookies, third-party
          services, and user rights before launch.
        </p>
        <h2>Information We Collect</h2>
        <p>
          We collect information you provide directly, such as through our contact form, and
          limited analytics data to understand how visitors use our site.
        </p>
        <h2>How We Use Information</h2>
        <p>
          We use the information collected to respond to enquiries, improve our services, and
          communicate with you about your project.
        </p>
        <h2>Contact</h2>
        <p>
          Questions about this policy can be sent to{" "}
          <a href={`mailto:${company.email}`}>{company.email}</a>.
        </p>
      </div>
    </section>
  );
}
